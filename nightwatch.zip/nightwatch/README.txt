NIGHTWATCH SETUP
=======================
Install node.js
Install Java Development Kit
Get nightwatch.zip from RC_Library
Extract nightwatch.zip to C:\, this will create a dev\nightwatch directory
update environment variable path: C:\dev\nightwatch\node_modules\nightwatch\drivers\

edit projects nightwatch.json: 
- change selenium.server_path to local sel-serv.jar
- set test_settings.<environment>.selenium.start_process to true

at prompt: node nightwatch.js -e <project config>

